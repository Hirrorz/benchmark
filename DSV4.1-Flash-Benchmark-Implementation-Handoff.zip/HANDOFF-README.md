# DSV4.1 Flash Benchmark 实施交接包

主文档：`DSV4.1-Flash-Benchmark-Implementation-Design.md`。

请先阅读主文档，按第15节分阶段实施，按第16节提交证据。文档可独立使用，不依赖此前聊天记录。代码仓库不包含在本包内；三个固定源码提交与获取地址见主文档0.2节。

本包内容：

| 文件 | 用途 |
|---|---|
| `DSV4.1-Flash-Benchmark-Implementation-Design.md` | 修改原因、实施方案、目标接口、文件清单、验证与验收要求 |
| `validate-cp-design.mjs` | 独立的CPU几何oracle，仅依赖Node.js内置模块 |
| `cp-design-validation.json` | 已有CPU oracle的通过记录与64K示例 |
| `source-manifest.json` | 源码分析时固定的提交、关键文件SHA256及算术示例 |
| `HANDOFF-README.md` | 本说明 |

在解压目录执行：

```sh
node validate-cp-design.mjs
```

该脚本会重写同目录的 `cp-design-validation.json`，运行若干秒后输出统计。预期status为passed，统计为5392个plan、16178608个query检查、23360824个压缩写入检查、14864415个halo检查、3327040个tail映射检查。

这个oracle只检查提出的几何方案，不导入目标benchmark、不调用任何NPU算子，也不证明新增Python/runtime实现已通过。实施时仍须将生产实现输出接入独立reference和测试；NPU数值、HCCL/MoE协议、稳定性和性能均需在目标环境另行验证。

本包是设计交付，尚未实施benchmark运行代码，未给出950实测性能结论。
