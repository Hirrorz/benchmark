# DSV4.1 Flash / Ascend 950 Prefill Benchmark 实施设计

版本：1.0  
日期：2026-11-01（Asia/Shanghai）  
用途：直接交给另一位 AI 或工程师实施；阅读本文件不需要此前聊天记录。  
状态：设计完成；尚未实施 NPU runtime 改造，尚无950性能结论。

---

## 0. 任务目标、范围与实施要求

### 0.1 用户目标

优化 `Hirrorz/benchmark` 中 DeepSeek V4.1 Flash 在 Ascend 950 上的 Prefill 性能，吸收 DeepInfer 与 CANN recipes 的有效实现，支持：

1. 构造不同前缀缓存命中率的 workload，不必每次真实计算缓存前缀。
2. 自动测试不同序列长度、命中率、batch、CP/DP/EP组合。
3. 在同一 workload 下选择更快的算子子图、CP通信方式和尾层CP策略。
4. 正确、可复现地报告完整Prefill计算时间、吞吐、显存、通信和实际执行配置。

主线是合成计算benchmark，不建设生产缓存存储系统、在线路由或完整服务系统。不要求每个测试点运行真实权重及真实prefix来证明精度。

但是，不能只检查tensor外形。算子次数、dtype/stride/量化格式、有效长度、索引分布、路由负载、内存驻留、通信及依赖关系共同决定性能。目标是复现明确的计算workload，避免合成数据令计算或访存意外退化。

### 0.2 基线源码

| 仓库 | URL | 本次分析固定提交 |
|---|---|---|
| 待改造benchmark | https://github.com/Hirrorz/benchmark | `eac678f460fe1e23c9fd12e397e93cdbc759be09` |
| 对照DeepInfer | https://github.com/deepseek-ai/DeepInfer | `553741557a57df44a46fb3ab72b6aafeaf945337` |
| 对照CANN recipes | https://gitcode.com/cann/cann-recipes-infer | `33b6f65b8ec6f0e092ce0f4fb3b514d7ca04a424` |

参考CANN模型路径为 `models/deepseek_v4_1/`，不是 `deepseek_v4/`。提交固定不代表运行机器上的算子二进制已固定，实施时还需记录实际加载的包/动态库版本或hash。

开始实施前读取目标checkout适用的 `AGENTS.md`，检查当前commit和工作区变更，确认本文的路径/缺口是否仍存在。保留已有用户变更；不要为了复现基线强制reset工作区。若版本不同，先记录差异，再调整接口，不机械覆盖新版实现。

### 0.3 测量边界

默认结果使用 `scope=model_prefill`：

- 已完成：加载/生成权重、生成输入、预填历史cache、建立通信组、JIT、静态metadata、预分配与预热。
- 计入：本次必要的工作state初始化、动态metadata、各层计算、通信、布局转换、第20层重分布、必要的cache更新及所声明输出state准备。
- 完成点：所有必要compute/CP/EP/侧流工作完成，最终hidden与声明的Prefill输出状态可用。
- 排除：tokenization、线上cache查询/拉取、请求排队、默认不包含LM head和sampling。

如增加其他scope，分别命名、分别输出，不能混称为TTFT。几何预准备模式与动态几何构造模式可分别测量，结果标签必须明确。

### 0.4 必须遵守的实现边界

- 优先复用现有配方、算子实现和runtime，不重写整个模型引擎。
- 第一阶段完成TP1、CP1/2/4/8、EP8的完整通路和varlen多请求；其他EP度和TP通路只有真正实现并验收后才标为支持。
- 先完成eager基线。当前代码的Prefill graph关闭，不能把旧文档中的graph-tail当作可直接开启的能力；图执行属于后续可选后端。
- 不用省略必要算子、切换workload、减少batch或隐藏padding来宣布加速。
- 不把unsupported或失败后的fallback记为原candidate成功。
- 无950环境时可以完成代码和CPU验证，但必须把NPU功能、稳定性及性能验证明确标为未执行；不得伪造结果。

### 0.5 两个对照组的吸收方向

| 来源 | 采用或保留为候选的思路 | 本设计落点 | 移植时必须补齐 |
|---|---|---|---|
| DeepInfer | projected输入交换、compact view、流式indexer | R3 projected_ag；R4直接compact；R6流式chunk | 昇腾后端能力、量化/解量化成本、CP多请求坐标 |
| CANN recipes | 本地压缩与量化后通信、融合indexer、metadata侧流及就绪事件 | R3 local_quant_ag；R6 vendor子图；R1内容metadata生命周期 | 任意合成命中起点、短段/空段、tail CP收缩、真实格式适配 |
| 当前benchmark | 已有算子/配方注册和可切换性能路径 | 增量扩展现有runner与registry | workload契约、能力标记、完整forward择优证据 |

这些是可移植的实现思路，不代表直接复制文件即可运行。不同数据表示的优劣以包含转换、通信和metadata的完整子图计时决定。

## 1. 模型结构与统一术语

下文层号从0开始。模型关键尺寸：hidden5120；主attention64×512；indexer32×128；SWA窗口128；main top-k512；候选块最多2048×8；40层；384 routed experts、top-6、1 shared expert；Engram位于第1、14层。

| 层号 | 类型 | main/index KV source | index/top-k source |
|---|---|---|---|
| 0–1 | 纯SWA | 无global分支 | 无 |
| 2–7 | SWA+C2 | 2 | 2 |
| 8–13 | SWA+C2 | 8 | 8 |
| 14–19 | SWA+C2 | 14 | 14 |
| 20–23 | SWA+C1 | 20 | 20 |
| 24–27 | SWA+C1 | 20 | 24 |
| 28–31 | SWA+C1 | 20 | 28 |
| 32–35 | SWA+C1 | 20 | 32 |
| 36–39 | SWA+C1 | 20 | 36 |

C2每两个原token产生一个完成的压缩键；C1不缩短长度。第20层是global KV source与consumer计算的边界。

两种replay必须独立：

- **Encoder prefix replay**：额外重算命中前缀末端，恢复所选encoder SWA状态。
- **Decoder bounded replay**：后半层只运行有限尾部Q，恢复decoder状态。

它们不是NPU graph replay。bounded replay本身收窄SWA可见域，不要求与关闭replay的全量计算逐位一致；验证时比较相同可见域与状态契约。

## 2. 七项改造总表

| 编号 | 改造 | 主要原因 | 最终产物 | 首要验证 |
|---|---|---|---|---|
| R1 | Workload与metadata统一 | 固定M+140混合不同状态；多处重复推导几何 | 整数请求描述、不可变stage view、完整plan hash | 边界/绝对位置/因果/slot oracle |
| R2 | CP分区与carry | 单请求/单offset假设；奇数边界、padding和空段不完整 | 多请求mirror、carry routes、有效行映射 | 每Q唯一归属、C2完成键唯一写入 |
| R3 | KV和SWA通信 | full hidden/latent通信、重复压缩；halo可能跨多段 | local quant rows、halo、可比较的通信候选 | 数据/索引对照、wire字节与次数 |
| R4 | 第20层及tail CP | 512→140二次裁剪；尾层CP固定造成小M | source/query分裂、一次迁移、tail CP候选 | 随行state完整、迁移oracle、整段计时 |
| R5 | MoE空origin协议 | CP收缩/空DP组会令rank无Q，但仍需EP服务 | zero/dummy通路、固定rounds与容量 | collective一致性、无超时、长跑 |
| R6 | 后端与host优化 | 混合子图/转换成本不清；热路径Python与同步 | capability、完整子图候选、预绑定执行序列 | 实际调用覆盖、数值抽查、idle/同步 |
| R7 | 自动矩阵和择优 | 手工开关、口径漂移、失败续跑困难 | sweep/autotune、结果schema、winner证据 | 故障恢复、同workload交错重复 |

## 3. 总体架构与目标接口

```text
ExperimentSpec
  → normalize_workloads()
  → build_parallel_topology()
  → compile_stage_plans()
  → resolve_backend_capabilities()
  → prepare_runtime()
  → execute_prefill()
  → measure / compare / confirm_winner / persist
```

一次编译得到stage、cache、buffer、通信和调用计划。运行期间按绑定好的调用序列执行，不通过不断修改cfg和重新解析env传播布局变化。

建议接口名称（提案，当前不一定存在）：

```python
case = normalize_workloads(experiment_case)
plan = compile_prefill_plan(case, model_spec, capabilities)
runtime = prepare_runtime(plan, device_inventory)
result = measure_prefill(plan, runtime, measurement_config)
```

核心对象：

```python
@dataclass(frozen=True)
class RequestWorkload:
    request_id: int
    total_len: int                 # L
    hit_len: int                   # H
    non_cached_len: int            # M
    encoder_replay_len: int        # E
    query_start: int               # S
    query_len: int                 # R
    decoder_keep: int              # K
    encoder_state_mode: str
    consumer_state_mode: str

@dataclass(frozen=True)
class SegmentDesc:
    request_id: int
    segment_id: int
    owner_rank: int
    abs_begin: int
    abs_end: int
    local_row_begin: int
    allocated_rows: int

@dataclass(frozen=True)
class CPStagePlan:
    parent_ranks: tuple[int, ...]
    active_ranks: tuple[int, ...]
    segments: tuple[SegmentDesc, ...]
    valid_rows_per_rank: tuple[int, ...]
    allocated_rows_per_rank: tuple[int, ...]
    transfer_plan: object
    cache_plan: object
    moe_plan: object
```

`PrefillPlan`进一步包含model/workload/topology/backend/buffer/measurement指纹、各stage plan和能力检查结果。设备张量绑定到runtime，避免让不可变逻辑计划持有不断改写的配置字典。

## 4. R1：统一命中workload与metadata

### 修改原因

当前 `assemble.py` / `points_runner.py` 采用M加replay_tail构造R，默认至少加140；同时cu、长度、offset、CP和replay在多个位置修改。会出现短序列R>L，或逻辑L、输入R、尾部K被混用。

用户允许构造cache，因此无需强制真实prefix。但必须说明构造了哪些state，否则相同命中率可以对应不同计算量。

### 修改方案

对请求i定义：

```text
L_i：总长；H_i：命中前缀；M_i=L_i−H_i：新增token
E_i：额外encoder重放；S_i=H_i−E_i：query绝对起点
R_i=L_i−S_i=M_i+E_i：实际query行数
K_i：decoder KEEP；T_i=L_i−min(L_i,K_i)：decoder重建尾段起点
```

合法性：`L>0`、`1<=M<=L`、`0<=E<=H`、`0<R<=L`。第一版不支持M=0的全命中输出复用，明确拒绝；如以后支持，应定义独立scope。

以整数M或H作为canonical输入。只有hit ratio时，建议固定HALF_UP规则：`M=clamp(floor((1−h)L+0.5),1,L)`，`H=L−M`；记录目标h和实际H/L。不要依赖不同语言的round默认行为。

第一版ratio输入要求 `0<=h<1`，超出范围直接拒绝；不能将h=1悄悄截成至少一个新增token。合法ratio因整数化得到的实际命中率与目标值可能不同，结果需同时保存。

`hit_alignment=token_exact`支持任意合成整数前缀；`block_aligned`把H归一化到声明的block边界，再重算M/E/R并报告实际命中率。

state profile：

| 字段 | 模式 | 语义 |
|---|---|---|
| encoder_state | restore | 提供S前的有效SWA历史 |
| encoder_state | replay | SWA从S开始截断，通过encoder重放重建 |
| consumer_state | rebuild | 不假定decoder历史恢复，后半层运行[T,L) |
| consumer_state | restore | 提供decoder历史，属于另一类明确标记的workload |

注意：encoder SWA缺失不等于C2 carry可以缺失。S处未完成的C2组state必须明确提供或按协议重建。

consumer rebuild且未缓存boundary hidden时，自动构造：

```text
E_swa = 0                         # encoder restore
        min(H,requested_replay)   # encoder replay，默认requested_replay=128
E_cover = max(0,min(L,K)−M)
E = max(E_swa,E_cover)
R = M+E
```

这里E不会超过H，因为两项本身都不超过H。用户显式指定manual E时执行合法性检查，不静默更改。K默认140；若声明backtracking约束，校验K覆盖window+backtracking；L<K时按L截断。

consumer restore是独立profile，可省去E_cover，但必须建立对应cache读取路径；未实现时列为unsupported。

迁移保留显式 `legacy_fixed_replay`，仅对旧公式本来合法的点位复现旧E；不得用新E较小的结果对比旧E较大的结果声称实现加速。

metadata分层：

1. 模型常量：source map、层角色、格式，runtime级复用。
2. 几何量：cu、positions、slots、mirror、halo/boundary映射，同case plan常驻。
3. 内容相关：top-k、candidate、依赖candidate的schedule，每forward/候选组失效。

小型区间描述在CPU编译，设备索引一次生成。运行期不以data_ptr相同替代内容相同，也不原地修改 `cfg._packed.cu` 触发stage切换。

若用侧流生成metadata，分别发布attention几何就绪和indexer/candidate schedule就绪事件。静态几何跨同plan forward复用；内容相关schedule在对应forward和候选组内复用。消费者只等待它实际读取的metadata，tail stage另有就绪事件，不沿用encoder旧事件。侧流执行和等待仍属于默认model_prefill范围。

### 涉及文件

`meta/metadata.py`、`meta/policy.py`、`core/assemble.py`、`layout/batch.py`、`layout/replay.py`、`core/runner.py`、`core/points_runner.py`。

### 验证方法与通过条件

- 精确测试M/H/E/S/R/T及各stage cu/positions；覆盖0%/高命中率、短序列、奇数H/S、混长请求、block对齐。
- 分别检查[S,H)重放和[H,L)新增的写mask，prefix写入必须为零。
- 相同case重复编译指纹稳定；改变任何影响几何的字段必须改变计划或失效缓存。
- 改变candidate内容但保持shape/地址时，内容schedule必须重建。
- 非法case在占卡/JIT前给出原因；不能执行到AICore后才发现R>L。

**通过条件：请求描述是唯一事实来源，所有几何消费者与oracle一致；不存在隐式固定+140。**

## 5. R2：CP拓扑、query分区与C2 carry

### 修改原因

当前CP基础已有mirror计划，但仍有单请求、单offset、分块fallback与空段限制。高命中使R变短，C2跨段组和padding更容易暴露问题。

### 修改方案A：拓扑

TP1、无PP时 `world=DP_enc×CP_enc`；EP是覆盖这些rank的专家分组，不再乘一次EP。

例：world8、CP4、DP2、EP8：parent CP groups为[0,1,2,3]和[4,5,6,7]，EP group为全部8rank。tail CP2可取[0,1]、[4,5]；tail CP1可取[0]、[4]。

组在测量前按全局一致顺序创建。第一阶段使用nested tail groups。CP收缩不自动创造新DP请求组；历史cache不跨原parent组迁移。

整机请求集合固定，允许某DP组无请求；这些rank仍可能需要服务EP。能力检查必须覆盖这种空origin。

### 修改方案B：mirror分区

CP=C>1时，对每请求：

```text
P_i=ceil(R_i/(2C))
segment j=[min(S_i+jP_i,L_i),min(S_i+(j+1)P_i,L_i))
owner(j)=j (j<C)，否则2C−1−j
rank r持有segment r和segment 2C−1−r
```

空段有效范围为空但可保留物理stride；每rank分配 `sum_i 2P_i` 行，实际有效行数另外记录。CP1走identity。

每有效行能映射到 `(request_id,p)`。p是真实绝对位置，不是packed全局行号。padding不写slot、不贡献有效top-k、不得进入真实路由或carry/halo/final输出。

后续增加 `mirror_aligned`：仅将内部理想切点对齐到绝对偶数位置，clamp于[S,L]；起终点不动，允许空段。各段长度会不同，按最长段分配stride。先完成exact+carry，再做aligned候选。

### 修改方案C：compressed-key所有权与carry

压缩比r的键j在 `r(j+1)−1` 完成，由持有completion token的segment唯一生成。

段[a,b)完成键范围为 `[floor(a/r),floor(b/r))`，其中 `j>=floor(H/r)` 才是新增写入。H为奇数时，跨越H的C2组属于新增完成键，不能按组起点是否早于H判断。

C2段起点a为奇数时，需要a−1的compressor state：

- a=S：使用此case的初始carry。
- a>S：从持有a−1的非空段获得，可能同rank也可能远端。

carry可交换末hidden后再投影，也可发送投影后的wkv/wgate；分别计量。接收方写 `(layer,request,segment)` 独立state slot，绝对相位正确。段尾未完成组不得当成有效KV行。

### 涉及文件

`cp/cp_layout.py`、`cp/cp_state.py`、`cp/cp_runtime.py`；新增建议 `cp/cp_plan.py`；同时更新compressor adapter、KV manager及所有调用方。

### 验证方法与通过条件

- CPU枚举检查有效query全覆盖、无重复，pad无真实所有权。
- 多请求不同S，CP1/2/4/8、R<2CP、空段、奇偶边界均覆盖。
- 每个新增compressed key恰写一次，旧key不写；half-group和terminal carry正确。
- NPU小规模同profile比较分段与CP1：先比整数metadata与输出有效范围，再按算子误差预算检查压缩数值。
- 不要求不同分块/量化路径全模型逐位一致；不能以此放宽整数因果、slot和ownership检查。

**通过条件：任意受支持batch/起点均有确定且可校验的分区、carry、key owner；没有单请求特判才能成立的路径。**

## 6. R3：Main/index KV与SWA通信

### 修改原因

当前plain CP可能gather完整hidden后各rank复算，部分分段路径仍有full latent过渡通信。SWA完整gather也可能浪费带宽；而只交换紧邻前一段又不能覆盖短segment。

### 修改方案A：cache驻留和格式

历史main/index read cache在请求parent CP组内复制，点位准备时预填，测量时不重新搬整个历史。按第2/8/14/20层source分别分配，consumer按source map alias。

统一 `CacheFormat` 描述：dtype、row_bytes、stride、scale格式/偏移、block_size、wire对齐。当前示例main320B、index64B+4B scale、SWA544B；以实际后端descriptor为准，不在多个文件继续重复硬编码。

paged地址：`block_table[request,j//block_size]*block_size+j%block_size`。dense拼接坐标由adapter生成，主KV与index-K的物理地址不能直接混用。

### 修改方案B：本地压缩与量化后交换

source层：local hidden→carry→local compressor→normalized latent；分别做main RoPE/quant和index-K projection/quant；按ownership打包AG并scatter各replica。

只传新增完成键，缓存旧键不传。主KV和index-K载荷可分开，也可拼成一条对齐record；实际wire stride包含padding。输出count和目标slot由区间提前确定，不做热路径D2H计数。

保留 `projected_ag` 作为另一完整候选：本地projected input AG后压缩。full hidden AG只保留明确的参考/诊断模式，不作为默认优化目标。

基础 `kv_update_scope=query_masked` 对query区处理后mask旧键；可选 `new_only` 仅为新增键计算global projection/compression，要求明确H处carry来源，作为单独优化验收。

### 修改方案C：SWA halo

W=128包含当前token。段[a,b)外部所需范围：

```text
[max(visible_start,a−127),a)
```

visible_start：encoder restore可读取S之前已恢复的窗口；encoder replay取S；decoder rebuild取T。

每段最多发布最后min(段长,127)行。接收端按区间交集从所有需要的前序非空段拼halo，不只读紧邻前一段。140行/CP8下段长约9，后段可能依赖许多前段。

同rank数据本地使用；跨rank数据才通信。本地attention scratch按 `[halo|segment body]` 建立绝对位置映射。初版用固定halo AG，后续增加静态稀疏交换；小R保留 `full_current_ag` 候选比较，不能硬编码halo必快。

历史SWA与当前scratch分离，读出历史前不得覆盖alias ring区。量化wire复用同一次producer生成的packed行/scale，避免通信重做不同口径的量化。BF16 attention适配所需解量化，成本计入。

### 通信时序和生命周期

初版每CP communicator一条有序通信流，同组顺序一致：carry（如需要）→halo→main/index rows。计算侧在carry交换期间计算Q；KV通信与后续独立计算重叠。事件依赖编译成无环DAG。

consumer层不重复global source KV通信，但每层仍按本层SWA数据执行必要halo交换。某collective能否跳过由整个group的静态计划决定，不能局部if跳过。跨stream buffer声明producer、consumer、last-use event；不能只靠Python引用存活。

### 涉及文件

`ops/exec_ops.py`、`ops/exec_indexer.py`、`cp/cp_runtime.py`、新增CP plan、`layout/kv_manager.py`及格式/后端adapter。

### 验证方法与通过条件

- 与完整gather reference比较逻辑键、scale、scatter slot与SWA有效索引；多前驱halo范围必须完整。
- 用合法非零量化数据，验证wire pack/unpack；检查NaN和未写有效行。
- trace核对实际通信次数/字节，区分有效、pad和collective复制。
- 检查source以后consumer确实复用，没有额外全量压缩、load/repack或full latent AG。
- 覆盖短段、空段、跨rank carry、不同batch；反复运行检查side-stream竞态。

**通过条件：数据与所选reference契约一致；local_quant路径不再包含全hidden/latent AG；SWA小段不漏历史，收益有完整source子图实测。**

## 7. R4：第20层一次compact与独立tail CP

### 修改原因

当前benchmark第20层最多保留512行，21层再裁140；默认CP也不根据尾部小M调整。可能多算、多搬一次，并加重后20层host与小矩阵瓶颈。

CP收缩主要改善小M核与通信效率；它本身不保证消除host下发瓶颈。host瓶颈需结合R6的预绑定、减少调度及可选graph单独测量，不能仅以CP_tail=1宣布解决。

### 修改方案

划分stage：

| stage | 输入/工作 | 并行 |
|---|---|---|
| Encoder：0–19层 | R行Q、必要global KV更新 | CP_enc |
| Boundary source：20层 | 所有必要的main/index KV更新 | 保留source布局/ownership |
| Boundary query+tail：20层Q至39层 | rebuild时[T,L) | CP_tail |

第20层source分支保留必要的非compacthidden，query分支直接迁移到最终tail布局；source cache事件保证attention读取前已就绪。第20层生成的新C1 candidate供24/28/32/36层消费，不搬过期C2 candidate。

重分布以 `(request,p)` 建old_owner/new_owner：相同rank本地切片，跨rank预先计划counts/offsets。仅搬下一stage真正消费的行和字段：HC trunk/residual、所需post/comb/pre mix等按dtype打包。不能丢随行state或随意降低精度。

通信实现两级：

1. contribution AG兼容基线；
2. 支持并验收后使用静态split的all-to-all/P2P，仅向目标发送必要行。

无跨rank迁移时不发AG；不gather全部R行hidden。固定512只作为某后端真实对齐要求的显式padding候选，不作为算法语义。

tail候选：fixed mirror、较小CP/CP1、replicated tail。replicated必须说明attention与MoE是否重复，完整计入重复工作，不计为新增token。

收缩后active ranks来自parent组中已有KV replica，不迁移整个历史。组在测量前创建；空origin能力通过R5检查，否则对应candidate禁用。

### 具体预期例子

L65536、H63570、M1966、E128：S63442、R2094、K140、T65396。CP_enc4、P262：

| rank | head区间 | tail区间 | 有效/分配行 |
|---|---|---|---|
| 0 | [63442,63704) | [65276,65536) | 522/524 |
| 1 | [63704,63966) | [65014,65276) | 524/524 |
| 2 | [63966,64228) | [64752,65014) | 524/524 |
| 3 | [64228,64490) | [64490,64752) | 524/524 |

tail140行全部在旧rank0；CP_tail1无需跨rank搬运，CP_tail2迁移70个唯一行，CP_tail4迁移108个唯一行。这里是行路由数量，不等于实际wire字节。

### 涉及文件

`core/runner.py`、`layout/replay.py`、`cp/cp_plan.py`、`cp/cp_state.py`、`cp/cp_runtime.py`、`recipes.yaml`、HC/boundary adapter。

### 验证方法与通过条件

- CPU检查每个tail行恰映射一次；不同请求/旧新CP/空段均覆盖。
- 构造带逻辑row tag的hidden及各HC字段，迁移后逐字段检查tag/dtype/shape。
- 确认full source KV仍覆盖全部必要新增键，不能因query裁尾只写K行。
- 同profile下比较fixed CP与shrink后的必要输出/可见域，数值按后端容差抽样。
- trace核对只发生一次布局切换，512不是默认有效计算量；boundary耗时计入完整forward。

**通过条件：一次切到最终tail布局、source更新完整、所有随行state正确；CP_tail可独立选择且没有暗中更改batch或KV前提。**

## 8. R5：MoE空origin、轮数和缓冲协议

### 修改原因

tail CP收缩、R很短、请求少于DP组数均会令某rank没有有效Q；但该rank持有的expert仍需处理其他rank派来的token。当前dummy span使用min(1,T)，T=0时仍是0，不能直接承担此协议。

### 修改方案

EP group和expert权重归属不随tail CP改变。每层固定chunk容量Q，编译统一轮数：

```text
rounds=max_{rank in EP}(ceil(required_origin_rows_rank/Q))
```

required行数明确区分真实、padding/dummy；所有rank执行相同协议轮数。某rank无本地origin，不代表可跳过expert服务。

后端能力分类：

- verified zero-origin：真正空origin参与dispatch/expert/combine；
- verified dummy-origin：独立预分配一行合法x/ids/weights，执行协议后丢弃该行输出；
- 未验证：禁用需要空origin的candidate，不能靠捕异常继续运行。

dummy不能取自空x[:1]；合法ids/weights、收到远端token的处理、结果隔离必须验收。dummy实际开销计入。

对称缓冲容量、地址、信号epoch在同一plan内稳定；各rank不得根据局部T重建。更换候选容量在准备阶段全组统一建立。必要的epoch/reset遵循后端协议，禁止为了省时跳过。

连续forward使用有界flight slots与device last-use fence，不能无限抢跑覆盖在途buffer，也不靠每层host同步管理生命周期。

### 涉及文件

`ops/exec_moe.py`、MoE后端adapter、`core/runner.py`、`core/points_runner.py`、CP/MoE plan及buffer manager。

### 验证方法与通过条件

- 静态检查各EP rank collective/round序列一致；空DP组和tail CP收缩都覆盖。
- 用少量真实origin分布在部分rank，其余zero/dummy，确认所有远端expert工作仍完成。
- 与全非空参考比较真实行结果，dummy不串入真实输出、gate或cache。
- 多chunk、不同DP负载、反复case切换、连续forward长跑，无barrier timeout、内存增长、epoch错误。
- 若后端不支持，结果必须是unsupported，不能卡死后标成功。

**通过条件：空origin是明确能力而非偶然可运行；各rank稳定履行相同轮数协议，真实输出不受dummy污染。**

## 9. R6：算子后端组合、流式indexer与host优化

### 修改原因

当前默认已混合CANN attention与DG indexer；部分注释过期，DG QSLI多请求仍受限。仅替换单kernel可能增加cache转换；大T分块实现还有整块logits分配或重复计算。热路径的Python分派、分配与同步会在尾层暴露。

### 修改方案A：按完整子图选择后端

| 子图 | 候选 | 必须计入 |
|---|---|---|
| 主attention | CANN量化paged MQSMLA / BF16 sparse FlashMLA | load/dequant、索引拼接、scratch |
| Indexer | vendor融合QLI/QSLI / DG+DeepSelect | split/combined cache、candidate schedule、restore |
| CP compressor | local_quant_ag / projected_ag | carry、quant、wire、scatter |
| SWA | halo / full_current_ag | pack、数据交换、索引、必要dequant |
| MoE | AscendC / DeepGEMM | routing、shared expert、通信、chunk |
| 输出投影 | fp8 einsum / transpose quant batchmatmul | cast、scale/weight布局转换 |

capability明确：dtype/stride/量化粒度、packed、CP、zero-origin、最大规模、对齐、graph安全性。只有整个组合可执行才进入竞赛。所有实际选择及fallback写入结果。

DG计划不无条件维护无消费者的vendor combined cache；vendor计划不付出无用dense K转换。DeepInfer的GPU-only MegaMHC/mega gate不能当成950已可用优化。

### 修改方案B：Indexer坐标与分块

DG本地每行Q带request/p：`ks=dense_base[request,r]`，`ke=ks+floor((p+1)/r)`。padding设零可见域；不支持时先压实有效行。

candidate先保留序列局部block id，再由adapter按API的ks余数语义转换，top-k最后还原到一致逻辑坐标。不能把不同KV池的physical index直接混用。

具体地，若API的第i个候选块从 `i*B+(ks%B)` 起读，序列局部候选c应传 `i=floor(ks/B)+c`，对应实际起点 `ks+c*B`。B为该API的候选块宽度。输出索引再按该API的实际返回坐标还原，不能直接加上或减去另一个KV池的base。用ks对B每一种余数做独立小例子验证；对零可见键的行，若后端无法接收空域，则不调用该行，填充约定的无效top-k，而不能读伪造的第0个键。

vendor segment[a,b)使用query有效长b−a、key长floor(b/r)、remainder b%r；不要对所有前段传最终L/r。段合批及共享block table只有验证后启用，否则显式逐段调用。

DG真正流式chunk：schedule→logits→top-k→restore→释放。去掉全段预计算及大 `[all_q,all_k]` 保留。workspace上限由plan预算决定。

### 修改方案C：减少host关键路径

- recipes/module tree只在编译阶段展开，执行direct bound call序列。
- env/import/权重pack/格式检查移出热路径；必要runtime检查保留轻量路径。
- 几何metadata和固定buffer常驻，移除不必要.item()/cpu()/阻塞H2D。
- 合并相同输入的投影、复用norm/quant中间结果；支持条件和额外转换明确。
- source投影/量化后尽早发通信，消费者才wait；不盲目增加通信stream。
- 当前以eager为必做。可选tail graph必须适配动态candidate、cache写入、MoE信号及固定地址；捕获成本单列，不能把数据相关结果录死。

### 涉及文件

`ops/exec_ops.py`、`ops/exec_indexer.py`、`ops/exec_moe.py`、`ops/fast_abi.py`、`modules/providers.py`及现有后端注册、`core/runner.py`；新增建议 `core/plan_compiler.py` 与capability描述。

### 验证方法与通过条件

- dry-run/plan dump和trace对齐：算子、次数、实际shape/dtype/stride、source角色、转换全部可解释。
- 多请求DG缺口真正补齐前，配置应选择受支持vendor或列unsupported，不能假装DG通过。
- chunk与非chunk同profile下抽样比有效分数/输出；top-k并列需按分数与有效域判断，不能仅靠id逐位一致。
- 用算子官方精度要求或预先声明误差预算验收浮点输出；禁止失败后任意放宽容差。
- profile检查完整forward wall、CPU launch、device idle、非必要同步和分配，确认所谓收益没有挪出计时边界。
- 大规模workspace不随all_q×all_k无界增长；没有sparse先整段再重复chunk。

**通过条件：子图可用能力清晰、无静默fallback；真实工作量完整，host/内存优化有trace与整图时延证据。**

## 10. R7：自动矩阵、测量、择优和续跑

### 修改原因

大量env开关与手工测试难以覆盖长短序列/命中率/CP；固定每DP请求数会在更换CP时改变整机workload；失败重试和结果指纹不足容易混入错误配置或旧结果。

### 修改方案A：两种运行模式

- `sweep`：逐点运行指定策略，输出完整矩阵。
- `autotune`：在能力/显存约束内选择子图、通信、CP_tail、MoE chunk等，完整forward确认winner。

目标分开：固定整机请求集合最小化延迟；固定硬件/显存预算可调batch最大化吞吐。不能混在一张best表中。

### 修改方案B：目标配置示例

以下为待实现schema，不是声称现有CLI已支持：

```yaml
schema_version: 1
model: dsv4_1_flash
mode: autotune
resources:
  world_size: 8
  ep_size: 8
  tp_size: 1
workloads:
  lengths: [8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576]
  hit_ratios: [0.0, 0.5, 0.9, 0.95, 0.97, 0.99]
  global_request_counts: [1, 8]
  hit_alignment: token_exact
  encoder_state: replay
  encoder_replay_tokens: 128
  consumer_state: rebuild
  decoder_keep_tokens: 140
  cache_seed: 41
  route_profile: balanced
parallel:
  encoder_cp: [1, 2, 4, 8]
  tail_mode: auto
  tail_cp: [1, 2, 4, 8]
  partition: [mirror_exact]
backends:
  attention: auto
  indexer: auto
  moe: auto
  cp_compressor: [local_quant_ag, projected_ag]
  swa: [halo, full_current_ag]
execution:
  metadata: prepared_geometry
  tail_executor: eager
  kv_update_scope: query_masked
measurement:
  scope: model_prefill
  objective: min_forward_latency
  statistic: median
  include_boundary: true
  include_dynamic_metadata: true
  confirm_winner: true
```

不要求第一批一次实现全部auto组合：schema区分requested与supported，按里程碑逐步启用，并列出所有排除原因。

### 修改方案C：自动执行

1. normalize所有case，按能力和显存预估裁剪。
2. 按不可热切换的runtime配置分组启动常驻worker。许多模块导入时读取env，因此不得在同一进程随意改env冒充切换成功。
3. 准备/JIT/预热候选，组件微基准仅用于剪枝。
4. 对少数候选执行完整forward；每个实际点位实测，不把邻近点位推测当最优。
5. 交错重复确认winner；差异在噪声内可标记相当，不硬报微小收益。
6. 每点原子落盘，重启后按指纹跳过已完成结果；设备错误后销毁/重建worker，不复用污染context。

超时、OOM、unsupported、runtime_error、validation_failed分别记录。watchdog要有清理策略；错误case不能使其他点位永久失去续跑能力。

### 修改方案D：测量和结果

开始前统一对齐；结束点覆盖compute/CP/EP及侧流，取所有rank完成耗时的最大值。计时区间内不逐层打印、加host barrier或清空cache；需要的state初始化不能移出区间。

延迟模式与连续提交吞吐模式分别输出；吞吐统一使用新增 `sum(M)/time`，另报R、padding、dummy及replica重复行。

结果至少包含：

```text
case_id / plan_hash / status / error
source commits / driver+CANN+torch+operator binary fingerprints
normalized requests: L,H,M,E,S,R,K,target_hit,actual_hit
world / EP / TP / encoder_DP / CP_enc / CP_tail / active_ranks
partition / per-stage valid+allocated+dummy+replicated rows
requested+actual backends / fallback / capability exclusions
metadata mode / state profile / seed / route+KV distribution / weight residency
wall median+spread / aggregate new tokens per second / peak HBM
boundary time+unique moved rows / CP wire bytes+calls / MoE rounds
warmup+JIT+prepare costs separately / repetitions / timestamp
```

profiling数据可单独对少数代表点采集，避免把profiler开销混入主noprof结果。调优缓存key覆盖硬件/软件/算子二进制和完整workload，不仅是T或CP。

### 涉及文件

`core/points_runner.py`、`core/launch_mini.py`、`core/run.py`、`tools/run.sh`及结果/trace工具；新增建议 `tools/run_matrix.py`、`configs/experiments/`、结果schema和autotuner。

### 验证方法与通过条件

- dry-run枚举完整请求矩阵、归一化几何、合法/非法组合和排除原因。
- 固定case改变CP时整机请求集合不变，row/token分母正确。
- 人工插入一个失败/超时点，验证错误隔离、结果原子性和续跑。
- 重启后相同指纹复用；更换软件/数据分布/状态profile必须失效。
- winner带同workload、相同范围的交错重复原始数据，不只一个最小值。
- 抽查最终结果中的actual backend与trace一致。

**通过条件：一个矩阵配置能无人干预执行受支持组合，解释排除项，保存可重现结果，并输出有完整forward实测依据的winner。**

## 11. 合成数据、cache和重复运行的公共规范

以下要求服务于性能workload，不是要求完整模型语义精度：

1. 有限非零数据、合法scale，范围稳定；有效区域不得来自未初始化内存。
2. prefix main/index只读；新增区域每次可覆写，不清零整个O(L)池。
3. initial SWA/C2 seed与working state分离，不能让上次L处的ring状态污染本次S。
4. 请求默认物理隔离；prefix sharing单独指定和记录。
5. 随机数据以case/request/source/absolute-position确定；CP变化不改变同一逻辑行的数据。
6. 默认独立层权重保留相应内存footprint；跨层权重共享仅作为显式合成模式，不能与独立权重结果混称。
7. KV索引局部性、物理block分布和MoE balanced/skew可配置；零K/重复index仅作诊断，不作默认性能分布。
8. 整图测量执行真实indexer；预生成top-k只允许在明确标记的组件微基准中替代。
9. Engram规模、放置位置及TP记录；hash的上下文按请求绝对位置，不能将segment开头当请求开头。
10. 所有跨流/跨forward缓冲声明寿命与epoch；内存和信号重用遵循后端协议。

## 12. 测试矩阵与具体预期值

### 12.1 CPU与NPU小规模边界集合

覆盖L/R：1、2、3、7、127、128、129、139、140、141、255、256、257、1024；S/H奇偶；CP1/2/4/8；batch1及混长batch2/5；R<2CP、空段、多前驱halo、零新增C2键、tail CP8→1、部分DP组空输入。

### 12.2 可手算的workload用例

| 用例 | 输入假设 | 预期 |
|---|---|---|
| 无命中 | L1024，M1024，consumer rebuild140 | H0，E0，S0，R1024 |
| 高命中+encoder restore | L65536，M1966，K140 | H63570，E0，R1966 |
| 高命中+encoder replay128 | 同上 | E128，S63442，R2094 |
| 新增不足tail覆盖 | L1024，M10，restore/rebuild140 | H1014，E130，S884，R140 |
| 前缀不足128可重放 | L1024，M922，replay128 | H102，E102，S0，R1024 |
| 半组跨命中点 | r2，H5，L6 | 新写j2，completion在p5；旧j0/1不写 |
| 尚未完成新C2组 | r2，H6，L7 | 无新增完成键，但需处理terminal carry |
| 极短分区 | R1，CP8 | 唯一有效query，其他物理行无效，不写真实slot |
| 多前驱halo | tail140，CP8 | 最后短段历史可能跨多个前序segment |
| CP收缩零迁移 | 上述64K例，CP4→1 | tail140行本地切片，跨rank唯一行数0 |

### 12.3 NPU性能代表矩阵

先用小规模通过功能，再扩到L=8K/64K/256K/1M、命中0/90/97/99%、全机请求数1/8、CP1/2/4/8；按内存与能力过滤。winner确认后再扩大完整用户矩阵。

性能比较需同时固定E/K、state profile、数据分布、权重驻留、请求集合和软件版本。变更算法工作量的结果可以报告，但必须与同工作量实现提速分开解释。

## 13. 已有验证证据及其限制

本设计此前有纯CPU oracle `validate-cp-design.mjs`，结果文件 `cp-design-validation.json`：

```text
status: passed
batch/CP/partition plans: 5392
query ownership checks: 16,178,608
compressed write ownership checks: 23,360,824
halo read checks: 14,864,415
tail row mapping checks: 3,327,040
```

它验证所提区间、mirror、write ownership、halo来源与tail映射，不执行现有Python CP实现，不运行NPU，不验证CANN/DeepGEMM精度、HCCL、MoE或性能。

交接包可附此oracle作参考；实现者必须为生产实现接入独立测试，不能把旧oracle通过直接当作新增runtime通过。仅拿本文件也可按第12节重建reference与用例。

## 14. 文件级任务清单

| 文件/目录（相对benchmark根） | 必要工作 |
|---|---|
| `meta/metadata.py` | RequestWorkload/immutable stage view；逐请求绝对坐标 |
| `meta/policy.py` | 归一化配置，requested/actual策略；移除热路径env决策 |
| `core/assemble.py` | 从规范workload生成stage，不再固定M+140 |
| `layout/batch.py`、`layout/replay.py` | 消费stage view，移除原地cu传播布局 |
| `cp/cp_layout.py` | exact mirror、varlen、空段、CPU reference |
| 新 `cp/cp_plan.py` | carry/halo/KV/boundary/terminal-state routes及MoE计划 |
| `cp/cp_state.py` | plan→设备索引/缓冲绑定，不用单个scalar offset |
| `cp/cp_runtime.py` | 固定通信计划、pack/scatter、events、AG基线和静态交换 |
| `layout/kv_manager.py` | source ownership、格式descriptor、seed/work分离 |
| `ops/exec_ops.py` | local compressor、SWA halo、attention adapter与直接调用 |
| `ops/exec_indexer.py` | varlen+CP、ks/ke、K复用、candidate坐标、真流式chunk |
| `ops/exec_moe.py` | zero/dummy origin、统一rounds、固定buffer容量 |
| `modules/providers.py`等现有registry | 子图capability、实际选择与显式fallback |
| 新 `core/plan_compiler.py` | 配方展开、融合/转换选择、DAG和能力检查 |
| `core/runner.py` | 执行计划，第20层一次切换、生命周期管理 |
| `core/points_runner.py`、`core/launch_mini.py` | sweep/tune、worker分组、计时、隔离、续跑 |
| `recipes.yaml` | 声明source/query分裂与必要依赖，准备阶段展开 |
| `tools/`、`configs/experiments/` | 矩阵入口、结果schema、winner/trace报表 |
| `tests/`或现有测试目录 | CPU不变量、NPU适配、分布式稳定性及结果恢复测试 |

允许根据现有模块结构调整新文件名，但不能省略其责任。优先扩展现有registry/runner接口，不建立并存的第三套几何或后端选择逻辑。

## 15. 分阶段实施与退出条件

| 阶段 | 实施内容 | 进入下一阶段的条件 |
|---|---|---|
| P0：基线与契约 | 核对版本，记录环境；R1、plan dump、legacy有效点基线、结果字段 | CPU几何/配置校验通过，所有计时范围可解释 |
| P1：固定CP正确路径 | R2、多请求、carry、有效行/slot，先保留可用通信基线 | 小规模CP1/2/4/8后端适配通过；unsupported明确 |
| P2：通信优化 | R3、量化行和halo、source/K复用、流式indexer | 与reference数据/索引一致，无冗余大通信，稳定运行 |
| P3：边界与空输入 | R4一次compact＋R5零origin，固定tail后再收缩 | source/state完整、EP协议通过、CP_tail候选可独立测 |
| P4：后端与host | R6子图组合、预绑定、预分配、侧流重叠 | 同workload trace完整，收益由完整forward确认 |
| P5：矩阵择优 | R7自动运行、恢复、winner确认、扩大矩阵 | 一份配置可运行、解释排除项、保存可复现winner |
| 可选扩展 | aligned分区、new_only、优化静态交换、更多EP/TP、tail graph | 每项独立capability/功能/稳定性/性能验收 |

每阶段产生可运行增量，不一次重构所有路径。不得在P1失败时通过关闭indexer、MoE或cache写入获得“可运行”结果。新增候选先与既有可用候选共存；完成对应验收后才更新默认策略。

## 16. 实施AI的交付格式与最终验收

### 每阶段交付

1. 实际修改文件和接口，说明解决哪个R编号。
2. 可执行命令/配置；明确命令是已运行还是待950执行。
3. CPU/NPU/分布式/性能各自的结果与原始产物路径。
4. 已支持与unsupported组合、已知限制、实际fallback。
5. 与基线同workload的变化，说明减少的是计算、通信、metadata还是host空泡。

### 最终验收清单

- [ ] R1：没有隐式M+140或多源几何；归一化配置与输出行数一致。
- [ ] R2：多请求、不同起点、奇偶carry、padding/空段均可验证。
- [ ] R3：本地量化通信和halo可测；无默认full hidden/latent冗余；source复用有效。
- [ ] R4：第20层一次切换；source更新完整；CP_tail独立且迁移成本计入。
- [ ] R5：空origin、统一rounds、固定buffer及连续运行通过，失败能力明确禁用。
- [ ] R6：后端组合真实可用，indexer流式，实际算子图与标签一致，无静默fallback。
- [ ] R7：矩阵能自动执行和续跑，结果指纹完整，winner有交错重复证据。
- [ ] 无950验证项明确未完成；不得因CPU测试通过而将整体优化标记为已完成。
- [ ] 不要求每个候选每点都更快，但默认选择必须来自正确且已验证候选；不把未测推断叫最优。

最优的边界是“已验收候选空间中的实测最优”，不承诺形式化证明全局最优。结果必须能回答：该点实际算了多少行、用了什么CP/后端、搬了多少数据、为什么更快。

## 附录A：关键源码入口

以下链接固定到分析提交，实施时仍需核对当前checkout：

- [benchmark workload公式](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/core/assemble.py)
- [benchmark metadata](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/meta/metadata.py)
- [benchmark CP layout](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/cp/cp_layout.py)
- [benchmark CP runtime](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/cp/cp_runtime.py)
- [benchmark compressor与attention](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/ops/exec_ops.py)
- [benchmark indexer](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/ops/exec_indexer.py)
- [benchmark MoE](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/ops/exec_moe.py)
- [benchmark boundary/runner](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/core/runner.py)
- [benchmark measurement](https://github.com/Hirrorz/benchmark/blob/eac678f460fe1e23c9fd12e397e93cdbc759be09/core/points_runner.py)
- [DeepInfer投影、KV与CP](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/model_executor/models/v4_modules/attn.py)
- [DeepInfer流式indexer](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/model_executor/models/v4_modules/index_attn.py)
- [DeepInfer compact view](https://github.com/deepseek-ai/DeepInfer/blob/553741557a57df44a46fb3ab72b6aafeaf945337/deepinfer/model_executor/input_metadata/yoco.py)
- [CANN compressor/carry/quant通信](https://gitcode.com/cann/cann-recipes-infer/blob/33b6f65b8ec6f0e092ce0f4fb3b514d7ca04a424/models/deepseek_v4_1/models/modules/compressor.py)
- [CANN index-K通信与融合indexer](https://gitcode.com/cann/cann-recipes-infer/blob/33b6f65b8ec6f0e092ce0f4fb3b514d7ca04a424/models/deepseek_v4_1/models/modules/indexer.py)
- [CANN metadata与tail](https://gitcode.com/cann/cann-recipes-infer/blob/33b6f65b8ec6f0e092ce0f4fb3b514d7ca04a424/models/deepseek_v4_1/models/modeling_deepseek.py)

## 附录B：给实施AI的开工指令

> 请在保留现有工作区变更的前提下实施本设计。先核对源码基线和适用仓库指令，输出当前能力与本文差异；然后按第15节完成可运行增量。以R1的canonical workload与不可变stage plan为入口，优先实现固定CP多请求的正确路径，再优化量化KV/halo通信、第20层与tail CP、MoE空origin，最后自动调优。每个阶段附第16节的运行证据；没有950条件时完成可做的代码/CPU检查，并明确列出未运行的NPU项目。不要通过删算子、缩小未声明工作量、静默fallback、隐藏padding或改变计时边界获得加速。
