// Pure CPU oracle for the proposed geometry. Does not import or run NPU code.
import fs from 'node:fs';
import assert from 'node:assert/strict';

const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
const alignUp = (x, a) => Math.ceil(x / a) * a;
const stats = {batchPlans: 0, queries: 0, compressedWrites: 0, haloReads: 0, tailRows: 0};

function partition(requests, cp, aligned = false) {
  const ns = cp === 1 ? 1 : 2 * cp;
  const shards = Array.from({length: cp}, () => []);
  const segments = [];
  for (let req = 0; req < requests.length; req++) {
    const w = requests[req], s = w.L - w.R;
    const p = Math.ceil(w.R / ns);
    const bounds = Array.from({length: ns + 1}, (_, j) => {
      if (j === 0) return s;
      if (j === ns) return w.L;
      return aligned ? clamp(alignUp(s + Math.ceil(j * w.R / ns), 2), s, w.L)
        : Math.min(w.L, s + j * p);
    });
    const stride = Math.max(...bounds.slice(1).map((b,j) => b - bounds[j]));
    const base = shards.map(x => x.length);
    for (let j = 0; j < ns; j++) {
      const rank = j < cp ? j : 2 * cp - 1 - j;
      const half = j < cp ? 0 : 1;
      const seg = {req, j, rank, a: bounds[j], b: bounds[j + 1], stride,
        localBase: base[rank] + half * stride};
      segments.push(seg);
      for (let u = 0; u < stride; u++) {
        const abs = seg.a + u;
        shards[rank].push(abs < seg.b ? {req, abs, seg: j} : null);
      }
    }
  }
  assert.equal(new Set(shards.map(x => x.length)).size, 1);
  const byQuery = new Map();
  for (let rank = 0; rank < cp; rank++) {
    for (let row = 0; row < shards[rank].length; row++) {
      const q = shards[rank][row];
      if (!q) continue;
      const key = `${q.req}:${q.abs}`;
      assert(!byQuery.has(key));
      byQuery.set(key, {rank, row, ...q});
    }
  }
  return {shards, segments, byQuery};
}

function checkPlan(requests, cp, aligned) {
  const plan = partition(requests, cp, aligned);
  stats.batchPlans++;
  for (let req = 0; req < requests.length; req++) {
    const w = requests[req], s = w.L - w.R;
    assert(w.R > 0 && w.R <= w.L);
    assert(w.R >= Math.min(w.L, w.K));
    for (let p = s; p < w.L; p++) {
      assert(plan.byQuery.has(`${req}:${p}`));
      stats.queries++;
    }
    const segs = plan.segments.filter(x => x.req === req);
    for (const ratio of [1, 2]) {
      const seen = new Map();
      for (const seg of segs) {
        if (seg.a === seg.b) continue;
        for (let j = Math.floor(seg.a / ratio); j < Math.floor(seg.b / ratio); j++) {
          const completion = ratio * (j + 1) - 1;
          assert(completion >= seg.a && completion < seg.b);
          if (j < Math.floor(w.H / ratio)) continue;
          seen.set(j, (seen.get(j) ?? 0) + 1);
          stats.compressedWrites++;
        }
        if (ratio === 2 && seg.a % 2) {
          assert(seg.a === s || plan.byQuery.has(`${req}:${seg.a - 1}`));
        }
      }
      assert.equal(seen.size, Math.floor(w.L / ratio) - Math.floor(w.H / ratio));
      for (let j = Math.floor(w.H / ratio); j < Math.floor(w.L / ratio); j++) {
        assert.equal(seen.get(j), 1);
      }
    }
    for (const restore of [true, false]) {
      const visibleStart = restore ? Math.max(0, s - 127) : s;
      for (const seg of segs) {
        if (seg.a === seg.b) continue;
        for (let p = Math.max(visibleStart, seg.a - 127); p < seg.a; p++) {
          if (p < s) {
            assert(restore && p >= Math.max(0, s - 127));
          } else {
            const producer = segs.find(x => x.a <= p && p < x.b);
            assert(producer);
            assert(p >= Math.max(producer.a, producer.b - 127));
            assert(plan.byQuery.has(`${req}:${p}`));
          }
          stats.haloReads++;
        }
      }
    }
  }
  for (const ct of [1, 2, 4, 8].filter(x => x <= cp)) {
    const tailRequests = requests.map(w => ({...w, R: Math.min(w.L, w.K)}));
    const tail = partition(tailRequests, ct, aligned);
    for (const [key, destination] of tail.byQuery) {
      const source = plan.byQuery.get(key);
      assert(source && destination.req === source.req && destination.abs === source.abs);
      stats.tailRows++;
    }
    assert.equal(tail.byQuery.size, tailRequests.reduce((s,w) => s+w.R,0));
  }
  assert.equal(plan.byQuery.size, requests.reduce((s,w) => s+w.R,0));
}

let seed = 0x41f1a5;
const rand = n => {seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed % n;};
const batches = [];
for (const L of [1, 2, 3, 7, 127, 128, 129, 139, 140, 141, 255, 256, 257, 1024, 8192, 65536, 1048576]) {
  for (const suffix of [1, 2, 3, 10, 127, 128, 129, 140, 141, 511, 1966]) {
    const M = Math.min(L, suffix), H = L - M, K = 140;
    for (const es of [0, 128]) {
      const E = Math.min(H, Math.max(es, Math.min(L,K)-M));
      batches.push([{L,H,K,R:M+E}]);
    }
  }
}
for (let t = 0; t < 300; t++) {
  const reqs = [];
  for (let i = 0, n = 1 + rand(5); i < n; i++) {
    const L = 1 + rand(1048576), M = Math.min(L, 1 + rand(4096)), H=L-M, K=140;
    const E=Math.min(H,Math.max(rand(2)?128:0,Math.min(L,K)-M));
    reqs.push({L,H,K,R:M+E});
  }
  batches.push(reqs);
}
for (const reqs of batches) for (const cp of [1,2,4,8]) for (const aligned of [false,true]) checkPlan(reqs,cp,aligned);

const exampleRequests = [{L:65536,H:63570,K:140,R:2094}];
const examplePlan=partition(exampleRequests,4,false);
const example={workload:{...exampleRequests[0],M:1966,E:128,S:63442},
  encoderCp:4,segments:examplePlan.segments,
  tailCandidates:[1,2,4].map(ct=>{
    const tail=partition(exampleRequests.map(x=>({...x,R:140})),ct,false);
    let crossingRows=0;
    for(const [key,dst] of tail.byQuery)if(examplePlan.byQuery.get(key).rank!==dst.rank)crossingRows++;
    return {tailCp:ct,physicalRowsPerActiveRank:tail.shards[0].length,uniqueTailRows:tail.byQuery.size,crossingRows};
  })};
const result={status:'passed',scope:'CPU geometry only; not backend, numerical, or NPU validation',stats,example};
const out=new URL('./cp-design-validation.json',import.meta.url);
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
